//
//  ViewController.swift
//  WebServiceTrial
//
//  Created by user on 1/29/18.
//  Copyright © 2018 user. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var emailTxtFld: UITextField!
    @IBOutlet weak var pwdTxtFld: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func signBtnActn(_ sender: UIButton) {
  
    let email = emailTxtFld.text!
    let pwd = pwdTxtFld.text!
        
        let paramDict = [
            "user": [
                "email":email,
                "password":pwd
            ]
            ] as [String : Any]
        
        loginService(queryParams : paramDict)
        
    
    }
    
    

    //MARK: - LoginWebService CAll
    

    func loginService(queryParams : [String : Any])
    {
        self.view.endEditing(true)
        
        
        RTWebService.sharedInstance.postLoginControl(loginDict: queryParams as NSDictionary, completionBlock:
            {
                (error , response ) -> Void in
                
                if let responseObj = response
                {
                    print(response)
                    
                    if (responseObj["error"] == nil) {
                        
                    let model = CommonObjects(dictionary: responseObj as NSDictionary) as CommonObjects
                        
                    RTUserDefaults.sharedInstances().setAccessToken(accessToken: String(model.auth_token))
                    RTUserDefaults.sharedInstances().setEmailID(userID: String(model.email))

                        
                    let nextVC:HomeViewController = self.storyboard?.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                    self.navigationController?.pushViewController(nextVC, animated: false)
                        
                    }
                    
                    else {
                        
                        let errorMsg = responseObj["error"] as! String

                        if(String.NonNilString(str: errorMsg).characters.count > 0)
                        {
                            let alert = UIAlertController(title: "", message: errorMsg, preferredStyle: UIAlertControllerStyle.alert)
                            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }

                   }
                    
                }
                else
                {
                    if error != nil {
                        if !(error?.localizedDescription.isEqual("cancelled"))!
                        {
                            //ProgressHUD .shared() .hide()
                            print("Error :\((error?.localizedDescription)!)")
                            
                            
                        }
                    }
                }
        });
    }
    
}


