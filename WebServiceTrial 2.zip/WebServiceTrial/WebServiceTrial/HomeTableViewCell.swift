//
//  HomeTableViewCell.swift
//  WebServiceTrial
//
//  Created by user on 1/30/18.
//  Copyright © 2018 user. All rights reserved.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var overLay: UIView!
    @IBOutlet weak var custAdd: UILabel!
    @IBOutlet weak var excessTime: UILabel!
    @IBOutlet weak var actualTime: UILabel!
    @IBOutlet weak var restaurantIm: UIImageView!
    @IBOutlet weak var custState: UILabel!
    @IBOutlet weak var postCode: UILabel!
    @IBOutlet weak var restaurantLab: UILabel!
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var city: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
