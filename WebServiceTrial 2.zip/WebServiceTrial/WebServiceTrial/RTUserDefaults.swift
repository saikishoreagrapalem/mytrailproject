//
//  RTUserDefaults.swift
//  
//
//  Created by ev_mac19 on 23/11/17.
//  Copyright © 2017 ev_mac19. All rights reserved.
//

import UIKit
import CoreLocation


let instance                = RTUserDefaults()
let RTUserDefault           = UserDefaults.standard

class RTUserDefaults: NSObject, NSKeyedArchiverDelegate {

    class func sharedInstances() -> RTUserDefaults
    {
        return instance
    }

    // MARK: - UUID Unique key
    
    func setDeviceUUID(deviceUUID:String) {
        
        RTUserDefault.setValue(deviceUUID, forKey: "kDeviceUUID")
    }
    func getDeviceUUID() -> String {
        
        if let deviceUUID = RTUserDefault.value(forKey: "kDeviceUUID")
        {
            return (deviceUUID as? String)!
        }
        else
        {
            return ""
        }
    }
    
    // MARK: - Device Token
    
    func setDeviceToken(deviceToken:String) {
        
        RTUserDefault.setValue(deviceToken, forKey: "kDeviceToken")
    }
    func getDeviceToken() -> String {
        
        if let deviceToken = RTUserDefault.value(forKey: "kDeviceToken")
        {
            return (deviceToken as? String)!
        }
        else
        {
            return ""
        }
    }
    
    // MARK: - AccessToken
    
    func setAccessToken(accessToken:String) {
        
        RTUserDefault.setValue(accessToken, forKey: "kAccessToken")
    }
    func getAccessToken() -> String {
        
        if let accessToken = RTUserDefault.value(forKey: "kAccessToken")
        {
            return (accessToken as? String)!
        }
        else
        {
            return ""
        }
    }
    
    // MARK: - UserID
    
    func setEmailID(userID:String) {
        
        RTUserDefault.setValue(userID, forKey: "kemailID")
    }
    func setEmailID() -> String {
        
        if let userID = RTUserDefault.value(forKey: "kemailID")
        {
            return (userID as? String)!
        }
        else
        {
            return ""
        }
    }

    // MARK: - CurrentLocationAddress
    
    func setCurentLocationAddress(currentLocationAddress : CurrentLocationModel)
    {
        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: currentLocationAddress)
        RTUserDefault.setValue(encodedObject, forKey: "kCurrentLocationAddressModel")
        RTUserDefault.synchronize()
    }
    
    func getCurentLocationAddress() -> CurrentLocationModel {

        if let currentLocationAddress = RTUserDefault.data(forKey: "kCurrentLocationAddressModel")
        {
            let model = NSKeyedUnarchiver.unarchiveObject(with: currentLocationAddress)
            return model as! CurrentLocationModel
        }
        else
        {
            return CurrentLocationModel()
        }
    }

    // MARK: - User Details Model
    
//    func setUserDetails(userDetails : UserRecordsModel)
//    {
//        NSKeyedArchiver.setClassName("RTUserDefaults", for: RTUserDefaults.self)
//        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: userDetails)
//        RTUserDefault.setValue(encodedObject, forKey: "kUserRecordsModel")
//        RTUserDefault.synchronize()
//    }
    
//    func getUserDetails() -> UserRecordsModel {
//
//        if let userDetails = RTUserDefault.data(forKey: "kUserRecordsModel")
//        {
//            NSKeyedUnarchiver.setClass(RTUserDefaults.self, forClassName: "RTUserDefaults")
//            let model = NSKeyedUnarchiver.unarchiveObject(with: userDetails)
//            return model as! UserRecordsModel
//        }
//        else
//        {
//            return UserRecordsModel()
//        }
//    }

    // MARK: - CurrentLocation
    
    func setCurrentLocation(currentLocation:CLLocation) {
        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: currentLocation)
        RTUserDefault.setValue(encodedObject, forKey: "kcurrentLocation")
        RTUserDefault.synchronize()
    }
    func getCurrentLocation() -> CLLocation {
        
        if let currentLocation = RTUserDefault.data(forKey: "kcurrentLocation")
        {
            let currentLocation = NSKeyedUnarchiver.unarchiveObject(with: currentLocation)
            return currentLocation as! CLLocation
        }
        else
        {
            return CLLocation()
        }
    }
    
    
    
    
    
    // MARK: - Current Race Delay Time
    
    func setCurrentRaceDelayTime(raceDelayTime:Double)
    {
        RTUserDefault.setValue(raceDelayTime, forKey: "kRaceDelayTime")
    }
    func getCurrentRaceDelayTime() -> Double {
        
        if let raceDelayTime = RTUserDefault.value(forKey: "kRaceDelayTime")
        {
            return (raceDelayTime as? Double)!
        }
        else
        {
            return 3.0
        }
    }

    // MARK: - Current Race Admin Time
    
    func setCurrentRaceAdminStart(RaceAdminStart:Date) {
        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: RaceAdminStart)
        RTUserDefault.setValue(encodedObject, forKey: "kRaceAdminStart")
        RTUserDefault.synchronize()
    }
    func getCurrentRaceAdminStart() -> Date {
        
        if let raceAdminStart = RTUserDefault.data(forKey: "kRaceAdminStart")
        {
            let raceAdminStart = NSKeyedUnarchiver.unarchiveObject(with: raceAdminStart)
            return raceAdminStart as! Date
        }
        else
        {
            return Date()
        }
    }
    
    // MARK: - Current Race Start Time
    
    func setCurrentRaceStart(RaceStart:Date) {
        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: RaceStart)
        RTUserDefault.setValue(encodedObject, forKey: "kraceStart")
        RTUserDefault.synchronize()
    }
    func getCurrentRaceStart() -> Date {
        
        if let raceStart = RTUserDefault.data(forKey: "kraceStart")
        {
            let raceStart = NSKeyedUnarchiver.unarchiveObject(with: raceStart)
            return raceStart as! Date
        }
        else
        {
            return Date()
        }
    }

    // MARK: - Race isAdminStart
    
    func setIsAdminStart(isAdminStart:Bool) {
        
        RTUserDefault.setValue(isAdminStart, forKey: "kIsAdminStart")
    }
    func getIsAdminStart() -> Bool {
        
        if let isAdminStart = RTUserDefault.value(forKey: "kIsAdminStart")
        {
            return (isAdminStart as? Bool)!
        }
        else
        {
            return true
        }
    }

    // MARK: - Race isTripStart
    
    func setIsTripStart(isTripStart:Bool) {
        
        RTUserDefault.setValue(isTripStart, forKey: "kIsTripStart")
    }
    func getIsTripStart() -> Bool {
        
        if let isTripStart = RTUserDefault.value(forKey: "kIsTripStart")
        {
            return (isTripStart as? Bool)!
        }
        else
        {
            return true
        }
    }

    // MARK: - Race isTripEnd
    
    func setIsTripEnd(isTripEnd:Bool) {
        
        RTUserDefault.setValue(isTripEnd, forKey: "kIsTripEnd")
    }
    func getIsTripEnd() -> Bool {
        
        if let isTripEnd = RTUserDefault.value(forKey: "kIsTripEnd")
        {
            return (isTripEnd as? Bool)!
        }
        else
        {
            return true
        }
    }

    // MARK: - Current Race Details Model
    
  //  func setCurrentRaceDetails(raceDetails : RaceDetailModel)
//    {
//        NSKeyedArchiver.setClassName("RTUserDefaults", for: RTUserDefaults.self)
//        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: raceDetails)
//        RTUserDefault.setValue(encodedObject, forKey: "kRaceDetailModel")
//        RTUserDefault.synchronize()
//    }
    
//    func getCurrentRaceDetails() -> RaceDetailModel {
//
//        if let raceDetails = RTUserDefault.data(forKey: "kRaceDetailModel")
//        {
//            NSKeyedUnarchiver.setClass(RTUserDefaults.self, forClassName: "RTUserDefaults")
//            let model = NSKeyedUnarchiver.unarchiveObject(with: raceDetails)
//            return model as! RaceDetailModel
//        }
//        else
//        {
//            return RaceDetailModel()
//        }
//    }
    
    // MARK: - Current Race Details Model
    
//    func setReceiveNotificationModel(notificationModel : ReceiveNotificationModel)
//    {
//        NSKeyedArchiver.setClassName("RTUserDefaults", for: RTUserDefaults.self)
//        let encodedObject = NSKeyedArchiver.archivedData(withRootObject: notificationModel)
//        RTUserDefault.setValue(encodedObject, forKey: "kReceiveNotificationModel")
//        RTUserDefault.synchronize()
//    }
    
//    func getReceiveNotificationModel() -> ReceiveNotificationModel {
//
//        if let notification = RTUserDefault.data(forKey: "kReceiveNotificationModel")
//        {
//            NSKeyedUnarchiver.setClass(RTUserDefaults.self, forClassName: "RTUserDefaults")
//            let model = NSKeyedUnarchiver.unarchiveObject(with: notification)
//            return model as! ReceiveNotificationModel
//        }
//        else
//        {
//            return ReceiveNotificationModel()
//        }
//    }


    
}
