//
//  HomeViewController.swift
//  WebServiceTrial
//
//  Created by user on 1/30/18.
//  Copyright © 2018 user. All rights reserved.
//

import UIKit
import Alamofire

class HomeViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    var transaction = [Transaction]()

    
    @IBOutlet weak var homeTblView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        homeTblView.register(UINib(nibName: "HomeTableViewCell", bundle: nil), forCellReuseIdentifier: "HomeTableViewCell")
        
        
        homeTblView.delegate = self
        homeTblView.dataSource = self
        
       
        
        let paramDict = [
            
            :] as [String : Any]
        
        self.homeService(queryParams : paramDict)

        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: table view delagate and data source
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        return self.transaction.count
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 105
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:HomeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "HomeTableViewCell") as! HomeTableViewCell
        
        let model = transaction[indexPath.row]
        cell.restaurantLab.text = String.NonNilString(str: model.restaurant_name)
        
        cell.custAdd.text = String.NonNilString(str: model.address?.street_name)
        
        let addressModel = model.customer?.addresses![0]
        cell.custAdd.text = String.NonNilString(str: addressModel?.city)        

        return cell
        
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
    }
    
    //MARK: - Accepted WebService Call
    
    func homeService(queryParams : [String : Any])
    {
        self.view.endEditing(true)
        
         RTConstants.notifyView 
        
        RTWebService.sharedInstance.getAcceptedHomeOrders(loginDict: queryParams as NSDictionary, completionBlock:
            {
                (error , response ) -> Void in
                
                let responseArr : NSMutableArray = (response as NSArray).mutableCopy() as! NSMutableArray
                
                for _ in 0 ..< responseArr.count
                {
                    self.transaction = [Transaction](dictionaryArray : responseArr as! [NSDictionary])

                }
                
                print(self.transaction)
                
                self.homeTblView.reloadData()
                
        });
    }
    
    



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
