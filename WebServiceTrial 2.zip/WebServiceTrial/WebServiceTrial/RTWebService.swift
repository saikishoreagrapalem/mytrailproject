//
//  RTWebService.swift
//
//
//  Created by ev_mac19 on 23/11/17.
//  Copyright © 2017 ev_mac19. All rights reserved.
//

import UIKit
import Alamofire

// Local Setup
//let APIBaseUrl                      : NSString! = "http://172.21.4.104/xyz/"
//let CLIENTID                        : NSString! = "123sample"
//let CLIENT_SECRET_ID                : NSString! = "123sample"

/*
 
 */

// Server Setup
let APIBaseUrl                      : NSString! = ""
let CLIENTID                        : NSString! = ""
let CLIENT_SECRET_ID                : NSString! = ""


// Registration and Login URL

let TWITTER                         : NSString! = ""
let FORGOT_PASSWORD                 : NSString! = ""
let USER_VERIFICATION               : NSString! = ""




// User Detail URL
let USER_DETAILS                    : NSString! = ""
let EDIT_USER_DETAILS               : NSString! = ""

// Notification URL
let NOTIFICATION_LIST               : NSString! = ""
let UPDATE_BADGE_COUNT              : NSString! = ""


//Race URL
let CREATE_RACE                     : NSString! = ""
let EDIT_RACE                       : NSString! = ""
let DELETE_RACE                     : NSString! = ""
let CANCEL_RACE                     : NSString! = ""
let START_RACE                      : NSString! = ""
let END_RACE                        : NSString! = ""

let USER_LIST                       : NSString! = ""
let INVITE_RACERS_SPECTATORS        : NSString! = ""
let RACE_DETAILS                    : NSString! = ""
let MY_RACES_LIST                   : NSString! = ""
let ALL_RACES_LIST                  : NSString! = ""
let JOIN_RACES                      : NSString! = ""
let JOIN_CONFIRM                    : NSString! = ""
let ACCEPT_DECLINE_RACES            : NSString! = ""
let REMOVE_RACE_USER                : NSString! = ""

let RACE_FINAL_LOCATION_DETAIL      : NSString! = ""

//Vehicle URL
let CREATE_VEHICLE                  : NSString! = ""
let EDIT_VEHICLE                    : NSString! = ""
let VEHICLE_LIST                    : NSString! = ""

let userDefaults = UserDefaults()


typealias RTWebserviceStatusCompletionBlock = ( _ error : NSError?, _ responseDict : NSMutableArray)  -> Void
typealias RTWebserviceStatusCompletionPostBlock = ( _ error : NSError?, _ responseDict : [String : AnyObject]?)  -> Void


class RTWebService {
    
    var request : Alamofire.Request?
    var initialRequest : Alamofire.Request?
    
    struct Singleton {
        static let sharedInstance = RTWebService()
    }
    
    class var sharedInstance: RTWebService {
        return Singleton.sharedInstance
    }
    
    func webServiceInitialPOSTCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionPostBlock) {
        
        debugPrint("DEBUG: \(paramValues)")
        
        Alamofire .request(url, method: .post, parameters: paramValues as? Parameters, encoding: URLEncoding.default, headers: nil) .responseJSON { response in
            
            debugPrint(response)
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as? [String : AnyObject])
            case .failure(let error):
                completionBlock(error as NSError?,nil)
            }
        }
    }
    
    func webServiceInitialPOSTCallWithMultiPartFormData(url : String, image : UIImage!, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {

        let imageData = UIImage(named: "blue")

        let url = try! URLRequest(url: URL(string:url)!, method: .post, headers: nil)

        Alamofire.upload(multipartFormData: { (multipartFormData) in
            if UIImage(named: "user_picture") != image
            {
               // multipartFormData.append(imageData!, withName: "Photo", fileName: "photo.jpg", mimeType: "image/jpg")
            }
            for (key, value) in paramValues {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
            }
        }, with: url, encodingCompletion: { (result) in
            switch result {

            case .success(let upload, _, _):

                upload.responseJSON { response in

                    debugPrint(response)

                    switch response.result {
                    case .success(let responseDict):
                        completionBlock( nil, responseDict as! NSMutableArray)
                    case .failure(let error):

                        completionBlock(error as NSError?, NSMutableArray())
                    }
                }

            case .failure(let encodingError):
                print(encodingError)
            }

        })
    }
    
    func webServicePOSTCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        
        debugPrint("DEBUG: \(paramValues)")
        
        let headers = [
            "Content-Type": "application/json"
        ]

        
        Alamofire .request(url, method: .post, parameters: paramValues as? Parameters, encoding: URLEncoding.default, headers: headers) .responseJSON { response in
            
            debugPrint(response)
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as! NSMutableArray )
            case .failure(let error):
                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }
    
    func webServiceJSONPOSTCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {

        debugPrint("DEBUG: \(paramValues)")

        let headers = [
            "Content-Type": "application/json"
        ]

        Alamofire .request(url, method: .post, parameters: paramValues as? Parameters, encoding: JSONEncoding.default, headers: headers) .responseJSON { response in

            debugPrint(response)

            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as! NSMutableArray )
            case .failure(let error):
                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }
    
    func webServicePOSTCallWithMultiPartFormData(url : String, image : UIImage!, imageKeyStr:String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {

        let headers = [
            "Content-Type": "application/json"
        ]

        let imageData = UIImage(named: "blue")

        let url = try! URLRequest(url: URL(string:url)!, method: .post, headers: headers)

        Alamofire.upload(multipartFormData: { (multipartFormData) in
            if UIImage(named: "add_race_logo") != image
            {
              //  multipartFormData.append(imageData!, withName: imageKeyStr, fileName: "photo.jpg", mimeType: "image/jpg")
            }
            for (key, value) in paramValues {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
            }
        }, with: url, encodingCompletion: { (result) in
            switch result {

            case .success(let upload, _, _):

                upload.responseJSON { response in
                    
                    debugPrint(response)

                    switch response.result {
                    case .success(let responseDict):
                        completionBlock( nil, responseDict as! NSMutableArray )
                    case .failure(let error):

                        completionBlock(error as NSError?, NSMutableArray())
                    }
                }

            case .failure(let encodingError):
                print(encodingError)
            }

        })
    }

    func webServiceInitialGETCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        
        debugPrint("DEBUG: \(paramValues)")
        
        
        Alamofire .request(url, method: .get, parameters: paramValues as? Parameters, encoding: URLEncoding.default, headers: nil) .responseJSON { response in
            
            debugPrint(response)
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as! NSMutableArray )
            case .failure(let error):
                
                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }
    
    func webServiceGETCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        
        
       let headers = ["User-Email":RTUserDefaults.sharedInstances().setEmailID(),"User-Token":RTUserDefaults.sharedInstances().getAccessToken()]
        
        debugPrint("DEBUG: \(paramValues)")
        
        request = Alamofire .request(url, method: .get, parameters: paramValues as? Parameters, encoding: URLEncoding.default, headers: headers) .responseJSON { response in
            
            debugPrint(response)
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, ((responseDict as! NSArray).mutableCopy() as! NSMutableArray))
            case .failure(let error):
                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }

    func webServicePUTCall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {

        let headers = [
            "Content-Type": "application/json"
        ]
        
        debugPrint("DEBUG: \(paramValues)")

        Alamofire .request(url, method: .put, parameters: paramValues as? Parameters, encoding: JSONEncoding.default, headers: headers) .responseJSON { response in

            debugPrint(response)

            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as! NSMutableArray)
            case .failure(let error):

                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }
    
    func webServiceDELETECall(url : String, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        
        let headers = [
            "Content-Type": "application/json"
        ]
        
        debugPrint("DEBUG: \(paramValues)")
        
        Alamofire .request(url, method: .delete, parameters: paramValues as? Parameters, encoding: JSONEncoding.default, headers: headers) .responseJSON { response in
            
            debugPrint(response)
            
            switch response.result {
            case .success(let responseDict):
                completionBlock( nil, responseDict as! NSMutableArray)
            case .failure(let error):
                
                completionBlock(error as NSError?, NSMutableArray())
            }
        }
    }

    
    func webServicePUTCallWithMultiPartFormData(url : String, image : UIImage!, paramValues : NSDictionary ,completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        
        let headers = [
            "Content-Type": "application/json"
        ]
        
        let imageData = UIImage(named: "blue")
        
        let url = try! URLRequest(url: URL(string:url)!, method: .put, headers: headers)
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            if UIImage(named: "user_picture") != image
            {
               // multipartFormData.append(imageData!, withName: "Photo", fileName: "photo.jpg", mimeType: "image/jpg")
            }
            for (key, value) in paramValues {
                multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key as! String)
            }
        }, with: url, encodingCompletion: { (result) in
            switch result {
                
            case .success(let upload, _, _):
                
                upload.responseJSON { response in
                    
                    debugPrint(response)
                    
                    switch response.result {
                    case .success(let responseDict):
                        completionBlock( nil, responseDict as! NSMutableArray )
                    case .failure(let error):
                        
                        completionBlock(error as NSError?, NSMutableArray())
                    }
                }
                
            case .failure(let encodingError):
                print(encodingError)
            }
            
        })
    }

    
    // MARK: - login
    
    func postLoginControl(loginDict : NSDictionary, completionBlock : @escaping RTWebserviceStatusCompletionPostBlock) {
        let url = String(format: "%@%@", APIBaseUrl,LOGIN) as String
        webServiceInitialPOSTCall(url: url, paramValues: loginDict, completionBlock: completionBlock)

    }
    
    // MARK: - Accepted Orders
    
    func getAcceptedHomeOrders(loginDict : NSDictionary, currrentLat : Double, currentLon : Double, completionBlock : @escaping RTWebserviceStatusCompletionBlock) {
        let url = String(format: "%@%@", APIBaseUrl,DRIVER_ACCEPTED_ORDER) as String
        webServiceGETCall(url: url, paramValues: loginDict, completionBlock: completionBlock)
        
    }
    
   

}



