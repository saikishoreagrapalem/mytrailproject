//
//  RTConstants.swift
//
//
//  Created by ev_mac19 on 23/11/17.
//  Copyright © 2017 ev_mac19. All rights reserved.
//

import UIKit
import SystemConfiguration
import AVFoundation
import CoreTelephony
//import SDWebImage

let Screen_Width = UIScreen.main.bounds.size.width
let Screen_Height = UIScreen.main.bounds.size.height

let APP_DELEGATE =  UIApplication.shared.delegate as! AppDelegate
let GOOGLE_PLACES_API_KEY = "12345678"

let FACEBOOK_ID = "hghj"
let TWITTER_CONSUMER_KEY = "klh"
let TWITTER_CONSUMER_SECRET_KEY = "jk"
let GOOGLE_PLUS_ID = "hg"


let User_Placeholder =  UIImage(named : "user_picture")
let Race_Placeholder =  UIImage(named : "add_race_logo")
let Vehicle_Placeholder =  UIImage(named : "upload_car_image")

let imageCache = NSCache<AnyObject, AnyObject>()
let alertTitleString = "abc"
class RTConstants: NSObject {
    
    class func isValidEmail(emailStr:String) -> Bool
    {
        let emailRegEx = "(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}" +
            "~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\" +
            "x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-" +
            "z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5" +
            "]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-" +
            "9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21" +
        "-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"
        
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: emailStr)
    }
    
    class func resizeImage(image: UIImage, newWidth: CGFloat, newHeight: CGFloat) -> Data!
    {
        var newWidth = newWidth
        var newHeight = newHeight
        if newWidth > 1000 || newHeight > 1000
        {
            let scaleFactor = newWidth / newHeight
            if newHeight > newHeight
            {
                newHeight = 1000
                newWidth = 1000 / scaleFactor
            }
            else
            {
                newHeight = 1000 / scaleFactor
                newWidth = 1000
            }
        }
        
        UIGraphicsBeginImageContext(CGSize(width:newWidth,height: newHeight))
        image.draw(in: CGRect(x:0, y:0,width: newWidth,height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return UIImageJPEGRepresentation(newImage!, 1.0)!
    }
    
    class func resizeImageWithTarget(image: UIImage, newWidth: CGFloat, newHeight: CGFloat, targetSide: CGFloat) -> UIImage
    {
        var newWidth = newWidth
        var newHeight = newHeight
        if newWidth > targetSide || newHeight > targetSide
        {
            let scaleFactor = newWidth / newHeight
            if newHeight > newHeight
            {
                newHeight = targetSide
                newWidth = targetSide / scaleFactor
            }
            else
            {
                newHeight = targetSide / scaleFactor
                newWidth = targetSide
            }
        }
        
        UIGraphicsBeginImageContext(CGSize(width:newWidth,height: newHeight))
        image.draw(in: CGRect(x:0, y:0,width: newWidth,height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
    
    class func resizeImage(image: UIImage, frameSize: CGFloat) -> UIImage {
        
        UIGraphicsBeginImageContext(CGSize(width: frameSize, height: frameSize))
        
        
        image.draw(in: CGRect(x: 0, y: 0,width: frameSize, height: frameSize))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
    }

    // Race Create local to live
    class func createRacedateFormatsedit(dateStr : String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        dateFormatter.timeStyle = DateFormatter.Style.medium
        dateFormatter.timeZone = TimeZone.current
        guard let date = dateFormatter.date(from: dateStr) else {
            return ""
        }
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        let resultDateStr = dateFormatter.string(from: date)
        return resultDateStr
    }
    
    // Race live to local
    class func dateFormatConverter(dateStr : String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        guard let date = dateFormatter.date(from: dateStr) else {
            return ""
        }
        let dateType = dateFormatter .date(from: dateStr)
        dateFormatter.dateFormat = "MMMM dd,yyyy / hh:mm a"
        dateFormatter.timeZone =  TimeZone.current
        let resultDateStr = dateFormatter .string(from: dateType!)
        return resultDateStr
    }
    
    // Notification listing
    class func dateFormat(dateStr: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        guard let date = dateFormatter.date(from: dateStr) else {
            return ""
        }
        dateFormatter.dateStyle = DateFormatter.Style.medium
        dateFormatter.timeStyle = DateFormatter.Style.medium
        dateFormatter.timeZone = TimeZone.current
        let resultDateStr = dateFormatter.string(from: date)
        return resultDateStr
    }
    
    class func notifyView(){
        
    }
    
    class func notificationdateFormat(dateStr: String) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        guard let date = dateFormatter.date(from: dateStr) else {
            return ""
        }
        dateFormatter.dateFormat = "MMM dd, yyyy"
        dateFormatter.timeZone =  TimeZone.current
        let resultDateStr = dateFormatter .string(from: date)
        return resultDateStr
    }
    
//    class func callWebserviceUpdateBatchCount()
//    {
//        RTWebService .sharedInstance .getUpdateBatchCountControl(completionBlock:
//            {
//                (error , response ) -> Void in
//                
//                if let responseObj = response
//                {
//                    print(response!)
//                    
//                    if (responseObj["meta"]?.value(forKey: "code") as! Int == 200)
//                    {
//                        ProgressHUD .shared() .hide()
//                        UIApplication.shared.applicationIconBadgeNumber = 0
//                        if  let messageStr = responseObj["notifications"]
//                        {
//                            let msgStr = (messageStr as! NSArray).firstObject as! String
//                            
//                            if(String.NonNilString(str: msgStr).characters.count > 0)
//                            {
//                                /*SweetAlert().showAlert(alertTitleString, subTitle: msgStr, style: AlertStyle.success, buttonTitle:NSLocalizedString("Ok", comment: ""), buttonColor:UIColor.colorFromRGB(0x6bd505) , otherButtonTitle: "", otherButtonColor: UIColor.clear) { (isOtherButton) -> Void in
//                                    if isOtherButton == true {
//                                        self.navigationController? .popViewController(animated: true)
//                                    }
//                                }*/
//                            }
//                        }
//
//                    }
//                    else if(responseObj["meta"]?.value(forKey:"code") as! Int == 400){
//                        ProgressHUD .shared() .hide()
//                        if let errorMes = (responseObj["meta"]?.value(forKey:"errorMessage"))
//                        {
//                            let errorStr = errorMes as! String
//                            
//                            if(String.NonNilString(str: errorStr).characters.count > 0)
//                            {
//                                //SweetAlert().showAlert(alertTitleString, subTitle: errorStr, style: .warning)
//                            }
//                        }
//                    }
//                    else
//                    {
//                        print(responseObj)
//                        ProgressHUD .shared() .hide()
//                        if let errorMes = (responseObj["meta"]?.value(forKey:"errorMessage"))
//                        {
//                            let errorStr = errorMes as! String
//                            
//                            if(String.NonNilString(str: errorStr).characters.count > 0)
//                            {
//                                //SweetAlert().showAlert(alertTitleString, subTitle: errorStr, style: .warning)
//                            }
//                        }
//                        else
//                        {
//                            print((error?.localizedDescription)!)
//                        }
//                    }
//                }
//                else
//                {
//                    if error != nil {
//                        if !(error?.localizedDescription.isEqual("cancelled"))!
//                        {
//                            ProgressHUD .shared() .hide()
//                            print("Error :\((error?.localizedDescription)!)")
//                            //SweetAlert().showAlert(alertTitleString, subTitle: "\((error?.localizedDescription)!)", style: .error)
//                        }
//                    }
//                }
//        })
//    }

}

// Mark: - Reachability

public class Reachability {
    
    class func isConnectedToNetwork() -> Bool {
        
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = (flags.rawValue & UInt32(kSCNetworkFlagsReachable)) != 0
        let needsConnection = (flags.rawValue & UInt32(kSCNetworkFlagsConnectionRequired)) != 0
        return (isReachable && !needsConnection)
    }
}

extension UIImage {
    
    func maskWithColor(color: UIColor) -> UIImage? {
        let maskImage = cgImage!
        
        let width = size.width
        let height = size.height
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
        
        context.clip(to: bounds, mask: maskImage)
        context.setFillColor(color.cgColor)
        context.fill(bounds)
        
        if let cgImage = context.makeImage() {
            let coloredImage = UIImage(cgImage: cgImage)
            return coloredImage
        } else {
            return nil
        }
    }
}

extension UIFont {
    
    class func customFontWithFontName(name : String, size : CGFloat) -> UIFont! {
        let font = UIFont(name: name, size: size)
        return font
    }
    
    class func customMediumFontWithSize(size : CGFloat) -> UIFont! {
        let font = UIFont(name: "SourceSansPro-Medium", size: size)
        return font
    }
    class func customRegularFontWithSize(size : CGFloat) -> UIFont! {
        let font = UIFont(name: "SourceSansPro-Regular", size: size)
        return font
    }
    
    class func customSemiBoldFontWithSize(size : CGFloat) -> UIFont! {
        let font = UIFont(name: "SourceSansPro-Semibold", size: size)
        return font
    }
}

extension UIView {
    
    func removeSubviews()
    {
        for view in self.subviews
        {
            view.removeFromSuperview()
        }
    }
    
    func width() -> Double {
        let frame: CGRect = self.frame
        return Double(frame.size.width)
    }
    
    func setWidth(value : Double)
    {
        var frame: CGRect = self.frame
        frame.size.width = round(CGFloat(value))
        self.frame = frame
    }
    
    func height() -> Double {
        let frame: CGRect = self.frame
        return Double(frame.size.height)
    }
    
    func setHeight(value : Double)
    {
        var frame: CGRect = self.frame
        frame.size.height = round(CGFloat(value))
        self.frame = frame
    }
    
    func size() -> CGSize {
        let frame: CGRect = self.frame
        return frame.size
    }
    
    func setSize(size : CGSize)
    {
        var frame: CGRect = self.frame
        frame.size.width = round(CGFloat(size.width))
        frame.size.height = round(CGFloat(size.height))
        self.frame = frame
    }
    
    func origin() -> CGPoint
    {
        let frame: CGRect = self.frame
        return frame.origin
    }
    
    func xPosition() -> Double
    {
        let frame: CGRect = self.frame
        return Double(frame.origin.x)
    }
    
    func yPosition() -> Double
    {
        let frame: CGRect = self.frame
        return Double(frame.origin.y)
    }
    
    func positionAtX(xValue : Double) {
        var frame: CGRect = self.frame
        frame.origin.x = round(CGFloat(xValue))
        self.frame = frame
    }
    
    func positionAtY(yValue : Double) {
        var frame: CGRect = self.frame
        frame.origin.y = round(CGFloat(yValue))
        self.frame = frame
    }
    
    func positionAtX(xValue : Double, yValue : Double) {
        var frame: CGRect = self.frame
        frame.origin.x = round(CGFloat(xValue))
        frame.origin.y = round(CGFloat(yValue))
        self.frame = frame
    }
    
    func positionAtX(xValue : Double, yValue : Double, width : Double) {
        var frame: CGRect = self.frame
        frame.origin.x = round(CGFloat(xValue))
        frame.origin.y = round(CGFloat(yValue))
        frame.size.width = CGFloat(width);
        self.frame = frame
    }
    
    func positionAtX(xValue : Double, yValue : Double, width : Double, height : Double) {
        var frame: CGRect = self.frame
        frame.origin.x = round(CGFloat(xValue))
        frame.origin.y = round(CGFloat(yValue))
        frame.size.width = CGFloat(width);
        frame.size.height = CGFloat(height);
        self.frame = frame
    }
    
    func positionAtX(xValue : Double, height : Double) {
        var frame: CGRect = self.frame
        frame.origin.x = round(CGFloat(xValue))
        frame.size.height = CGFloat(height);
        self.frame = frame
    }
    
    func bringToFront() {
        
        self.superview?.bringSubview(toFront: self)
    }
    
    func sendToBack() {
        
        self.superview?.sendSubview(toBack: self)
    }
}

extension UIBarButtonItem {
    
    class func backButtonItemWithTarget(target : Any, action: Selector) -> UIBarButtonItem
    {
        let button = UIButton(type: .custom) as UIButton
        button.setImage(UIImage(named: "back"), for: UIControlState.normal)
        button.frame = CGRect(x: 0, y: 0, width: 30 , height: 30)
        button.imageView?.contentMode = UIViewContentMode .center
        button.addTarget(target, action: action, for: UIControlEvents.touchUpInside)
        let barbtn = UIBarButtonItem(customView : button)
        return barbtn
    }
    
    class func menuButtonItemWithTarget(target : Any, action: Selector) -> UIBarButtonItem
    {
        let button = UIButton(type: .custom) as UIButton
        button.setImage(UIImage(named: "menu"), for: UIControlState.normal)
        button.frame = CGRect(x: 0, y: 0, width: 30 , height: 30)
        button.imageView?.contentMode = UIViewContentMode .center
        button.addTarget(target, action: action, for: UIControlEvents.touchUpInside)
        let barbtn = UIBarButtonItem(customView : button)
        return barbtn
    }
    
    class func itemWithTarget(titleString: String) -> UIBarButtonItem
    {
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 40))
        customView.backgroundColor = UIColor.clear
        
        let label = UILabel(frame: CGRect(x: 0, y: 10, width: 200, height: 20))
        label.text = titleString
        label.textColor = UIColor .white
        label.font = UIFont .customSemiBoldFontWithSize(size: 17.0)
        label.textAlignment = NSTextAlignment.left
        label.backgroundColor = UIColor.clear
        customView.addSubview(label)
        
        let barbtn = UIBarButtonItem(customView : customView)
        
        return barbtn
    }
    
    class func rightButtonItemWithTargetString(target : Any, action: Selector, titleString: String) -> UIBarButtonItem
    {
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 40))
        customView.backgroundColor = UIColor.clear
        
        let button = UIButton(type: .custom) as UIButton
        button.setTitle(titleString, for: UIControlState.normal)
        button.frame = CGRect(x: 0, y: 10, width:60, height: 20)
        button.setTitleColor(UIColor .white, for: .normal)
        button.titleLabel?.font = UIFont .customRegularFontWithSize(size: 14.0)
        button.titleLabel?.textAlignment = NSTextAlignment.left
        button.addTarget(target, action: action, for: UIControlEvents.touchUpInside)
        customView.addSubview(button)
        
        let barbtn = UIBarButtonItem(customView : customView)
        
        return barbtn
    }
    
    class func rightButtonItemWithTargetImages(target : Any, action: [Selector], titleImages: [UIImage]) -> UIBarButtonItem
    {
        let customView = UIView(frame: CGRect(x: 0, y: 0, width: titleImages.count * 35, height: 30))
        customView.backgroundColor = UIColor.clear
        
        var x = 5
        for i in 0..<titleImages.count {
            
            let button = UIButton(type: .custom) as UIButton
            button.setBackgroundImage(titleImages[i], for: UIControlState.normal)
            button.imageView?.contentMode = UIViewContentMode .center
            button.frame = CGRect(x: x, y: 0, width: 30, height: 30)
            button.addTarget(target, action: action[i], for: UIControlEvents.touchUpInside)
            customView.addSubview(button)
            x = x + 35
        }
        
        let barbtn = UIBarButtonItem(customView : customView)
        
        return barbtn
    }
}

extension UINavigationBar {
    
    override open func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        
        if ( self.point(inside: point, with: event)) {
            self.isUserInteractionEnabled = true
        } else {
            self.isUserInteractionEnabled = false
        }
        
        return super.hitTest(point, with: event)
    }
    
    func makeTransparent() {
        
        self.isTranslucent = false
        self.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.backgroundColor = UIColor.clear
        self.shadowImage = nil
        self.titleTextAttributes = [NSAttributedStringKey.font: UIFont .customSemiBoldFontWithSize(size: 17.0)!, NSAttributedStringKey.foregroundColor: UIColor.white]
        self.barTintColor = UIColor.clear
        self.tintColor = UIColor.clear
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        if statusBar.responds(to: #selector(setter: UIView.backgroundColor)) {
            statusBar.backgroundColor = UIColor.clear
        }
        hideBottomHairline()
    }
    func makeClear() {
        
        self.isTranslucent = true
        self.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.backgroundColor = UIColor.clear
        self.shadowImage = nil
        self.titleTextAttributes = [NSAttributedStringKey.font: UIFont .customSemiBoldFontWithSize(size: 17.0)!, NSAttributedStringKey.foregroundColor: UIColor.white]
        self.barTintColor = UIColor.clear
        self.tintColor = UIColor.clear
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        if statusBar.responds(to: #selector(setter: UIView.backgroundColor)) {
            statusBar.backgroundColor = UIColor.clear
        }
        hideBottomHairline()
    }
    func makeDefault() {
        
        self.isTranslucent = false
        self.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.backgroundColor = UIColor.fromRGB(rgb: 0x0f3669)
        self.shadowImage = nil
        self.titleTextAttributes = [NSAttributedStringKey.font: UIFont .customSemiBoldFontWithSize(size: 17.0)!, NSAttributedStringKey.foregroundColor: UIColor.white]
        self.barTintColor = UIColor.fromRGB(rgb: 0x0f3669)
        self.tintColor = UIColor.fromRGB(rgb: 0x0f3669)
        let statusBar: UIView = UIApplication.shared.value(forKey: "statusBar") as! UIView
        if statusBar.responds(to: #selector(setter: UIView.backgroundColor)) {
            statusBar.backgroundColor = UIColor.fromRGB(rgb: 0x0f3669)
        }
        showBottomHairline()
    }
    
    func hideBottomHairline() {
        let navBarHairlineImageView = findHairlineImageViewUnder(view: self)
        navBarHairlineImageView?.isHidden = true;
    }
    
    func showBottomHairline() {
        let navBarHairlineImageView = findHairlineImageViewUnder(view: self)
        navBarHairlineImageView?.isHidden = false;
    }
    
    func findHairlineImageViewUnder(view:UIView) -> UIImageView! {
        
        if view.isKind(of: UIImageView.self) && view.bounds.size.height <= 1.0
        {
            return view as! UIImageView;
        }
        
        for subview in view.subviews
        {
            let imageView = findHairlineImageViewUnder(view: subview)
            
            if let imgView = imageView
            {
                return imgView
            }
        }
        return nil
    }
}

extension UIColor {
    
    class func fromRGB(rgb:UInt32) -> UIColor {
        return UIColor(
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    class func fromRGB_Alpha(rgb:UInt32,alpha:Float) -> UIColor {
        return UIColor(
            red: CGFloat((rgb & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgb & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgb & 0x0000FF) / 255.0,
            alpha: CGFloat(alpha)
        )
    }
    
    class func defaultBlueColor() -> UIColor
    {
        return UIColor.fromRGB(rgb: 0x326bb7)
    }
    
    class func defaultGrayColor() -> UIColor
    {
        return UIColor.fromRGB(rgb: 0x929292)
    }
    
    class func defaultRedColor() -> UIColor
    {
        return UIColor.fromRGB(rgb: 0xE05F5D)
    }
    
}

extension String {
    
    static func widthForView(text:String, font:UIFont, height:CGFloat) -> CGFloat{
        let label =  UILabel(frame: CGRect(x: 0, y: 0, width: .greatestFiniteMagnitude, height: height))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        
        label.sizeToFit()
        return label.frame.width
    }
    
    static func NonNilString(str : String?) -> String
    {
        if str?.isEmpty == true
        {
            return ""
        }
        else if str?.isKind(of: NSString.self) == false
        {
            return ""
        }
        else if (str?.characters.count == 0)
        {
            return ""
        }
        else
        {
            return str == nil ? "" : str!
        }
    }
}

