//
//  RTModel.swift
//  RaceAndTrash
//
//  Created by ev_mac19 on 23/11/17.
//  Copyright © 2017 ev_mac19. All rights reserved.
//

import UIKit
import EVReflection



class RTModel: NSObject {
    
}

class CommonObjects: EVObject {
    
    var auth_token = String()
    var driver_id = Int()
    var email = String()
    var is_online = Int()
    var user_id = Int()
    var success = Int()
    
    override public func propertyMapping() -> [(keyInObject: String?, keyInResource: String?)] {
        return [(keyInObject: "ignoredProperty",keyInResource: nil), (keyInObject: "propertyInObject",keyInResource: "keyInJson")]
    }
    
}

public class Transaction: EVObject {
    var address: Address?
    var amountEntered: NSNumber?
    var restaurant_name: String?
    var is_future_order: NSNumber?
    var state: String?
    var createdBy: String?
    var preparing_minutes: String?
    var expected_pickup_time: String?
    var customer: Client?
    
    override public func propertyMapping() -> [(keyInObject: String?, keyInResource: String?)] {
        return [(keyInObject: "ignoredProperty",keyInResource: nil), (keyInObject: "propertyInObject",keyInResource: "keyInJson")]
    }

}

public class Address: EVObject {
   
    var city = String()
    var cross_street: String?
    var street_name: String?
    var short_state_name: String?
    var zip_code: String?
    var fullAddress: String?

    override public func propertyMapping() -> [(keyInObject: String?, keyInResource: String?)] {
        return [(keyInObject: "ignoredProperty",keyInResource: nil), (keyInObject: "propertyInObject",keyInResource: "keyInJson")]
    }

}

public class Client: EVObject {
    
    var addresses: [Address]?

    override public func propertyMapping() -> [(keyInObject: String?, keyInResource: String?)] {
        return [(keyInObject: "ignoredProperty",keyInResource: nil), (keyInObject: "propertyInObject",keyInResource: "keyInJson")]
    }

}

